﻿/// <reference path="knockout-3.4.0.js" />
/// <reference path="jquery-3.1.1.min.js" />
/*
View Model for a matrix grid
*/

function MatrixGrid(options) {

    //overide defaults object with the options using the jQuery facility
    var _defaults = {
        rowData: [],
        colData: [],
        displayMode: "All",
        dispayModes: ["All"],

        updateMode: "batched",
        updateModes: ["batched", "immediate"],

        columnEntityTypeName: "Columns",
        rowEntityTypeName: "Rows",
        load: function () {
            //Must Override this in the options!
            alert('No Loader function provided....');
            return;
        },
        save: function () {
            //Must Override this in the options!
            alert('No update function provided!');
            return;
        }
       

    }

    jQuery.extend(_defaults, options);//merge the optioons (if any) over the defaults

    var self = this; //standard technique to hold a reference to the constructed VM object

    self.displayModes = ko.observableArray(_defaults.displayModes);
    self.displayMode = ko.observable(_defaults.displayMode);
    
    self.updateMode = ko.observable(_defaults.updateMode);
    self.updateModes = ko.observableArray(_defaults.updateModes);

    self.cols = ko.observableArray(_defaults.colData);
    self.rows = ko.observableArray(_defaults.rowData);

    self.columnEntityTypeName = ko.observable(_defaults.columnEntityTypeName)
    self.rowEntityTypeName = ko.observable(_defaults.rowEntityTypeName)
    
    self.load = _defaults.load;
    self.save = _defaults.save;

    self.clear = function () {
        self.cols([]);
        self.rows([]);

    };

    self._lastNewID = 0;
    self.getNewID = function () { return -- self._lastNewID};//decrement and return


}