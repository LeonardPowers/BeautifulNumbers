﻿namespace WpfMatrixDemo.Data
{
    public class Person
    {
        public string CountryOfResidence { get; set; }
        public string Name { get; set; }        
    }
}