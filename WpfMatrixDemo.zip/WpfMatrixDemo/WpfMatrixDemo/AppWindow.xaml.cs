﻿namespace WpfMatrixDemo
{
    public partial class AppWindow : System.Windows.Window
    {
        public AppWindow()
        {
            InitializeComponent();
        }
    }
}