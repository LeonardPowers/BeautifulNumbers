﻿namespace MatrixLib.Matrix
{
    public partial class MatrixControl : System.Windows.Controls.ItemsControl
    {
        public MatrixControl()
        {
            InitializeComponent();
        }
    }
}