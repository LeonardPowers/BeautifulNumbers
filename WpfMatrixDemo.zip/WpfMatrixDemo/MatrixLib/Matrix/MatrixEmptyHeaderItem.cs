﻿namespace MatrixLib.Matrix
{
    /// <summary>
    /// Represents the 'blank' top-left item in a matrix.
    /// </summary>
    public class MatrixEmptyHeaderItem : MatrixItemBase
    {
    }
}